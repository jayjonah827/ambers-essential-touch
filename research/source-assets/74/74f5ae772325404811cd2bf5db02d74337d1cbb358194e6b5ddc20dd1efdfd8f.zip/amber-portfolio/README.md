# Amber's Essential Touch — Portfolio Case Study

Created for Jair Valley / Heyer Livin', 2026.

## Deliverables

- `index.html` — responsive independent portfolio case-study page.
- `styles.css` — responsive presentation styling.
- `ambers-essential-touch-behance.png` — 1400 × 9800 px vertical Behance upload.
- `behance-board.svg` — editable vector source for the Behance board.
- `assets/` — project photography and brand assets used by the presentation.

Open `index.html` in a browser to preview the independent page. Upload the PNG directly to Behance. Before publishing the linked client website, replace or remove all pending testimonials, journal drafts, and product-photo placeholders.
